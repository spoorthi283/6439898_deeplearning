USE bankdb;
CALL GenerateMonthlyStatements();
CALL ApplyAnnualFee();
CALL UpdateLoanInterestRates();
