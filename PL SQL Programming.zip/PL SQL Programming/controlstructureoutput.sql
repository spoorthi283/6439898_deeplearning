USE bankdb;
SELECT * FROM Loans;
ALTER TABLE Customers ADD COLUMN IsVIP BOOLEAN DEFAULT FALSE;
SELECT * FROM Customers WHERE IsVIP = TRUE;
CALL SendLoanReminders();  -- if you created this proc