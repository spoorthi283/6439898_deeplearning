CREATE DATABASE bankdb;
USE bankdb;
