USE bankdb;
-- ==========================================
-- Scenario 1: SafeTransferFunds Stored Procedure
-- ==========================================
DELIMITER //

CREATE PROCEDURE SafeTransferFunds(
    IN from_account_id INT,
    IN to_account_id INT,
    IN transfer_amount DECIMAL(10,2)
)
BEGIN
    DECLARE from_balance DECIMAL(10,2);
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
        SELECT 'Transfer failed. Transaction rolled back due to an error.' AS ErrorMessage;
    END;

    START TRANSACTION;

    -- Get source balance
    SELECT Balance INTO from_balance
    FROM Accounts
    WHERE AccountID = from_account_id
    FOR UPDATE;

    -- Check for sufficient funds
    IF from_balance < transfer_amount THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Insufficient funds in source account';
    END IF;

    -- Perform transfer
    UPDATE Accounts SET Balance = Balance - transfer_amount WHERE AccountID = from_account_id;
    UPDATE Accounts SET Balance = Balance + transfer_amount WHERE AccountID = to_account_id;

    COMMIT;
    SELECT 'Transfer successful.' AS Message;
END;
//

-- ==========================================
-- Scenario 2: UpdateSalary Stored Procedure
-- ==========================================
CREATE PROCEDURE UpdateSalary(
    IN emp_id INT,
    IN percent_increase DECIMAL(5,2)
)
BEGIN
    DECLARE emp_count INT;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        SELECT CONCAT('Error: Failed to update salary for EmployeeID ', emp_id) AS ErrorMessage;
    END;

    -- Check if employee exists
    SELECT COUNT(*) INTO emp_count FROM Employees WHERE EmployeeID = emp_id;

    IF emp_count = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Employee does not exist';
    END IF;

    -- Update salary
    UPDATE Employees
    SET Salary = Salary + (Salary * percent_increase / 100)
    WHERE EmployeeID = emp_id;

    SELECT 'Salary updated successfully.' AS Message;
END;
//

-- ==========================================
-- Scenario 3: AddNewCustomer Stored Procedure
-- ==========================================
CREATE PROCEDURE AddNewCustomer(
    IN cust_id INT,
    IN cust_name VARCHAR(100),
    IN dob DATE,
    IN balance DECIMAL(10,2)
)
BEGIN
    DECLARE cust_count INT;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        SELECT 'Error inserting new customer. Possible duplicate ID.' AS ErrorMessage;
    END;

    -- Check if customer already exists
    SELECT COUNT(*) INTO cust_count
    FROM Customers
    WHERE CustomerID = cust_id;

    IF cust_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Customer already exists with this ID';
    END IF;

    -- Insert new customer
    INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
    VALUES (cust_id, cust_name, dob, balance, NOW());

    SELECT 'Customer added successfully.' AS Message;
END;
//

DELIMITER ;
