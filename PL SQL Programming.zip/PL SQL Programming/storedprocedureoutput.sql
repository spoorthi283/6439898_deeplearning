USE bankdb;
SELECT * FROM Accounts WHERE AccountType = 'Savings';
SELECT * FROM Employees;
SELECT * FROM Accounts;
