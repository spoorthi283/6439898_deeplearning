USE bankdb;
INSERT INTO Customers VALUES (1, 'John Doe', '1985-05-15', 1000, NOW(), FALSE);
INSERT INTO Customers VALUES (2, 'Jane Smith', '1958-03-10', 12000, NOW(), FALSE);

INSERT INTO Accounts VALUES (1, 1, 'Savings', 1000, NOW());
INSERT INTO Accounts VALUES (2, 2, 'Checking', 1500, NOW());

INSERT INTO Loans VALUES (1, 2, 5000, 5.00, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 60 MONTH));

INSERT INTO Employees VALUES (1, 'Alice Johnson', 'Manager', 70000, 'HR', '2015-06-15');
