-- Exercise 7: Simulated Packages in MySQL
-- ========================================
-- CUSTOMER MANAGEMENT "PACKAGE"
-- ========================================

-- Procedure: Add new customer
DELIMITER //
CREATE PROCEDURE Customer_Add(
    IN cust_id INT,
    IN cust_name VARCHAR(100),
    IN dob DATE,
    IN balance DECIMAL(10,2)
)
BEGIN
    INSERT INTO Customers (CustomerID, Name, DOB, Balance, LastModified)
    VALUES (cust_id, cust_name, dob, balance, NOW());
END;
//

-- Procedure: Update customer details
CREATE PROCEDURE Customer_Update(
    IN cust_id INT,
    IN new_name VARCHAR(100),
    IN new_dob DATE
)
BEGIN
    UPDATE Customers
    SET Name = new_name,
        DOB = new_dob,
        LastModified = NOW()
    WHERE CustomerID = cust_id;
END;
//

-- Function: Get customer balance
CREATE FUNCTION Customer_GetBalance(cust_id INT)
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE bal DECIMAL(10,2);
    SELECT Balance INTO bal FROM Customers WHERE CustomerID = cust_id;
    RETURN bal;
END;
//

-- ========================================
-- EMPLOYEE MANAGEMENT "PACKAGE"
-- ========================================

-- Procedure: Hire new employee
CREATE PROCEDURE Employee_Hire(
    IN emp_id INT,
    IN emp_name VARCHAR(100),
    IN position VARCHAR(50),
    IN salary DECIMAL(10,2),
    IN dept VARCHAR(50),
    IN hire_date DATE
)
BEGIN
    INSERT INTO Employees (EmployeeID, Name, Position, Salary, Department, HireDate)
    VALUES (emp_id, emp_name, position, salary, dept, hire_date);
END;
//

-- Procedure: Update employee details
CREATE PROCEDURE Employee_Update(
    IN emp_id INT,
    IN new_position VARCHAR(50),
    IN new_salary DECIMAL(10,2)
)
BEGIN
    UPDATE Employees
    SET Position = new_position,
        Salary = new_salary
    WHERE EmployeeID = emp_id;
END;
//

-- Function: Calculate annual salary
CREATE FUNCTION Employee_AnnualSalary(emp_id INT)
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE annual_salary DECIMAL(10,2);
    SELECT Salary * 12 INTO annual_salary FROM Employees WHERE EmployeeID = emp_id;
    RETURN annual_salary;
END;
//

-- ========================================
-- ACCOUNT OPERATIONS "PACKAGE"
-- ========================================

-- Procedure: Open a new account
CREATE PROCEDURE Account_Open(
    IN acc_id INT,
    IN cust_id INT,
    IN acc_type VARCHAR(20),
    IN balance DECIMAL(10,2)
)
BEGIN
    INSERT INTO Accounts (AccountID, CustomerID, AccountType, Balance, LastModified)
    VALUES (acc_id, cust_id, acc_type, balance, NOW());
END;
//

-- Procedure: Close an account
CREATE PROCEDURE Account_Close(
    IN acc_id INT
)
BEGIN
    DELETE FROM Accounts WHERE AccountID = acc_id;
END;
//

-- Function: Get total customer balance across accounts
CREATE FUNCTION Account_TotalBalance(cust_id INT)
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE total DECIMAL(10,2);
    SELECT SUM(Balance) INTO total FROM Accounts WHERE CustomerID = cust_id;
    RETURN IFNULL(total, 0.00);
END;
//

DELIMITER ;
