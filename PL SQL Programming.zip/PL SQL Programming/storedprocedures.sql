DELIMITER //

-- ==========================================
-- Scenario 1: ProcessMonthlyInterest
-- ==========================================
CREATE PROCEDURE ProcessMonthlyInterest()
BEGIN
    UPDATE Accounts
    SET Balance = Balance + (Balance * 0.01)
    WHERE AccountType = 'Savings';

    SELECT 'Monthly interest of 1% applied to all Savings accounts.' AS Message;
END;
//

-- ==========================================
-- Scenario 2: UpdateEmployeeBonus
-- ==========================================
CREATE PROCEDURE UpdateEmployeeBonus(
    IN dept_name VARCHAR(50),
    IN bonus_percent DECIMAL(5,2)
)
BEGIN
    UPDATE Employees
    SET Salary = Salary + (Salary * bonus_percent / 100)
    WHERE Department = dept_name;

    SELECT CONCAT('Bonus of ', bonus_percent, '% applied to ', dept_name, ' department.') AS Message;
END;
//

-- ==========================================
-- Scenario 3: TransferFunds
-- ==========================================
CREATE PROCEDURE TransferFunds(
    IN from_acc INT,
    IN to_acc INT,
    IN amt DECIMAL(10,2)
)
BEGIN
    DECLARE from_bal DECIMAL(10,2);

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        SELECT 'Transfer failed. Transaction rolled back due to an error.' AS ErrorMessage;
    END;

    START TRANSACTION;

    -- Get source account balance
    SELECT Balance INTO from_bal
    FROM Accounts
    WHERE AccountID = from_acc
    FOR UPDATE;

    -- Check if sufficient balance
    IF from_bal < amt THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Insufficient funds in source account';
    END IF;

    -- Perform the transfer
    UPDATE Accounts SET Balance = Balance - amt WHERE AccountID = from_acc;
    UPDATE Accounts SET Balance = Balance + amt WHERE AccountID = to_acc;

    COMMIT;
    SELECT 'Funds transferred successfully.' AS Message;
END;
//

DELIMITER ;
