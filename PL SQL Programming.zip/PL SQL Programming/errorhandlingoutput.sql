USE bankdb;
SELECT * FROM Accounts;
SELECT * FROM Employees;
SELECT * FROM Customers;
CREATE TABLE ErrorLog (ErrorMsg TEXT, LoggedAt DATETIME DEFAULT NOW());
SELECT * FROM ErrorLog;
