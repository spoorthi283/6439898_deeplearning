

-- 🚫 Remove the ALTER TABLE if IsVIP already exists
-- ALTER TABLE Customers ADD IsVIP BOOLEAN DEFAULT FALSE;

-- Scenario 1: Apply 1% discount to loan interest rates for customers above 60
DELIMITER //

CREATE PROCEDURE ApplyLoanDiscount()
BEGIN
  DECLARE done INT DEFAULT FALSE;
  DECLARE cust_id INT;
  DECLARE dob DATE;

  DECLARE cur CURSOR FOR SELECT CustomerID, DOB FROM Customers;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

  OPEN cur;
  read_loop: LOOP
    FETCH cur INTO cust_id, dob;
    IF done THEN
      LEAVE read_loop;
    END IF;

    IF TIMESTAMPDIFF(YEAR, dob, CURDATE()) > 60 THEN
      UPDATE Loans
      SET InterestRate = InterestRate - 1
      WHERE CustomerID = cust_id;
    END IF;
  END LOOP;
  CLOSE cur;
END;
//

DELIMITER ;

-- Call procedure
CALL ApplyLoanDiscount();

-- Scenario 2: Promote VIPs
UPDATE Customers
SET IsVIP = TRUE
WHERE Balance > 10000;

-- Scenario 3: Display reminders for loans due in next 30 days
SELECT L.LoanID, C.Name, L.EndDate
FROM Loans L
JOIN Customers C ON L.CustomerID = C.CustomerID
WHERE L.EndDate BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY);
