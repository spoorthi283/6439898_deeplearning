USE bankdb;
UPDATE Customers SET Balance = Balance + 100 WHERE CustomerID = 1;
SELECT * FROM Customers;
INSERT INTO Transactions VALUES (3, 1, NOW(), 500, 'Deposit');
SELECT * FROM AuditLog;
-- Try inserting invalid transaction and see error
INSERT INTO Transactions VALUES (4, 2, NOW(), -100, 'Deposit');
