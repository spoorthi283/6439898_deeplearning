USE bankdb;
SELECT CalculateAge('1990-06-10');
SELECT CalculateMonthlyInstallment(50000, 7.5, 5);
SELECT HasSufficientBalance(1, 200);
