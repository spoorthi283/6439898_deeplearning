DELIMITER //

-- ==========================================
-- Scenario 1: GenerateMonthlyStatements
-- Retrieves current month's transactions per customer
-- ==========================================
CREATE PROCEDURE GenerateMonthlyStatements()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE acc_id INT;
    DECLARE cust_name VARCHAR(100);
    DECLARE txn_date DATE;
    DECLARE amount DECIMAL(10,2);
    DECLARE txn_type VARCHAR(10);

    DECLARE cur CURSOR FOR
        SELECT T.AccountID, C.Name, T.TransactionDate, T.Amount, T.TransactionType
        FROM Transactions T
        JOIN Accounts A ON T.AccountID = A.AccountID
        JOIN Customers C ON A.CustomerID = C.CustomerID
        WHERE MONTH(T.TransactionDate) = MONTH(CURDATE())
          AND YEAR(T.TransactionDate) = YEAR(CURDATE());

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO acc_id, cust_name, txn_date, amount, txn_type;
        IF done THEN
            LEAVE read_loop;
        END IF;

        SELECT CONCAT('Customer: ', cust_name, ', AccountID: ', acc_id,
                      ', ', txn_type, ' of ₹', amount, ' on ', txn_date) AS Statement;
    END LOOP;

    CLOSE cur;
END;
//

-- ==========================================
-- Scenario 2: ApplyAnnualFee
-- Deducts ₹100 annual fee from all accounts
-- ==========================================
CREATE PROCEDURE ApplyAnnualFee()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE acc_id INT;
    DECLARE fee DECIMAL(10,2) DEFAULT 100.00;

    DECLARE cur CURSOR FOR SELECT AccountID FROM Accounts;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;

    apply_fee_loop: LOOP
        FETCH cur INTO acc_id;
        IF done THEN
            LEAVE apply_fee_loop;
        END IF;

        UPDATE Accounts
        SET Balance = Balance - fee
        WHERE AccountID = acc_id;
    END LOOP;

    CLOSE cur;

    SELECT 'Annual fee of ₹100 applied to all accounts.' AS Message;
END;
//

-- ==========================================
-- Scenario 3: UpdateLoanInterestRates
-- Adds 0.5% to all loan interest rates
-- ==========================================
CREATE PROCEDURE UpdateLoanInterestRates()
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE loan_id INT;
    DECLARE current_rate DECIMAL(5,2);
    DECLARE new_rate DECIMAL(5,2);

    DECLARE cur CURSOR FOR
        SELECT LoanID, InterestRate FROM Loans;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;

    update_loop: LOOP
        FETCH cur INTO loan_id, current_rate;
        IF done THEN
            LEAVE update_loop;
        END IF;

        SET new_rate = current_rate + 0.5;

        UPDATE Loans
        SET InterestRate = new_rate
        WHERE LoanID = loan_id;
    END LOOP;

    CLOSE cur;

    SELECT 'Loan interest rates updated as per new policy (+0.5%).' AS Message;
END;
//

DELIMITER ;
CALL GenerateMonthlyStatements();

CALL ApplyAnnualFee();

CALL UpdateLoanInterestRates();
