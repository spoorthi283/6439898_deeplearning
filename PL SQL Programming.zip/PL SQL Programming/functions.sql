DELIMITER //

-- ==========================================
-- Scenario 1: CalculateAge
-- ==========================================
CREATE FUNCTION CalculateAge(dob DATE)
RETURNS INT
DETERMINISTIC
BEGIN
    RETURN TIMESTAMPDIFF(YEAR, dob, CURDATE());
END;
//

-- ==========================================
-- Scenario 2: CalculateMonthlyInstallment
-- ==========================================
-- Formula: EMI = P * r * (1 + r)^n / ((1 + r)^n - 1)
-- Where:
--   P = loan amount
--   r = monthly interest rate (annual rate / 12 / 100)
--   n = loan duration in months

CREATE FUNCTION CalculateMonthlyInstallment(
    loan_amount DECIMAL(10,2),
    annual_rate DECIMAL(5,2),
    duration_years INT
)
RETURNS DECIMAL(10,2)
DETERMINISTIC
BEGIN
    DECLARE r DECIMAL(10,6);
    DECLARE n INT;
    DECLARE emi DECIMAL(10,2);

    SET r = annual_rate / 12 / 100;
    SET n = duration_years * 12;

    SET emi = loan_amount * r * POW(1 + r, n) / (POW(1 + r, n) - 1);
    RETURN emi;
END;
//

-- ==========================================
-- Scenario 3: HasSufficientBalance
-- ==========================================
CREATE FUNCTION HasSufficientBalance(
    acc_id INT,
    required_amount DECIMAL(10,2)
)
RETURNS BOOLEAN
DETERMINISTIC
BEGIN
    DECLARE acc_balance DECIMAL(10,2);

    SELECT Balance INTO acc_balance
    FROM Accounts
    WHERE AccountID = acc_id;

    RETURN acc_balance >= required_amount;
END;
//

DELIMITER ;
