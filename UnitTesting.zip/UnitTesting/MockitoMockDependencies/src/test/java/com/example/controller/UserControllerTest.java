package com.example.controller;

import com.example.entity.User;
import com.example.service.UserService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class UserControllerTest {

    @Test
    public void testGetUser() {
        // ✅ Create mock
        UserService mockService = Mockito.mock(UserService.class);

        // ✅ Inject mock via constructor
        UserController controller = new UserController(mockService);

        User mockUser = new User();
        mockUser.setId(1L);
        mockUser.setName("Test User");

        Mockito.when(mockService.getUserById(1L)).thenReturn(mockUser);

        ResponseEntity<User> response = controller.getUser(1L);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Test User", response.getBody().getName());
    }
}
