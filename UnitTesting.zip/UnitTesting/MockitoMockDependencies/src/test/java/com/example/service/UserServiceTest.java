package com.example.service;

import com.example.entity.User;
import com.example.repository.UserRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class UserServiceTest {
    @Test
    public void testGetUserById() {
        // Create mock repository
        UserRepository mockRepo = Mockito.mock(UserRepository.class);

        // ✅ FIX: Inject mock via constructor
        UserService service = new UserService(mockRepo);

        // Sample user data
        User user = new User();
        user.setId(1L);
        user.setName("Test");

        // Stubbing
        Mockito.when(mockRepo.findById(1L)).thenReturn(Optional.of(user));

        // Execute
        User result = service.getUserById(1L);

        // Assert
        assertEquals("Test", result.getName());
    }

}
