package com.example;

public @interface SelectClasses {

    Class<EvenCheckerTest>[] value();

}
