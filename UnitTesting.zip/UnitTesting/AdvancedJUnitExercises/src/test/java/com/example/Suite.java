package com.example;

public @interface Suite {

}
