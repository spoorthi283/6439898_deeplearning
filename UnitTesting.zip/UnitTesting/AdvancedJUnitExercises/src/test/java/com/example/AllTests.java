package com.example;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;
import org.junit.platform.suite.api.IncludeEngines;

@Suite
@IncludeEngines("junit-jupiter")
@SelectClasses({
    EvenCheckerTest.class,
    ExceptionThrowerTest.class,
    PerformanceTesterTest.class,
    OrderedTests.class
})
public class AllTests {
}
