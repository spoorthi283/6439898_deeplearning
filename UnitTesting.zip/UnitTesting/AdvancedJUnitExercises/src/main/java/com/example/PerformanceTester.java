package com.example;

public class PerformanceTester {
    public void performTask() throws InterruptedException {
        Thread.sleep(400); // simulate work
    }
}