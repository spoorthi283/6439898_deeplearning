package com.example;

public class ExceptionThrower {
    public void throwException() {
        throw new IllegalArgumentException("Invalid input");
    }
}