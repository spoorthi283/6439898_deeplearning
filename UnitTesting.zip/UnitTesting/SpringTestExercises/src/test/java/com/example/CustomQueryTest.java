package com.example;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class CustomQueryTest {

    @Mock
    UserRepository userRepository;

    @InjectMocks
    UserService userService;

    public CustomQueryTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindByName() {
        List<User> users = Arrays.asList(new User());
        when(userRepository.findByName("Alice")).thenReturn(users);

        List<User> result = userRepository.findByName("Alice");
        assertEquals(1, result.size());
    }
}