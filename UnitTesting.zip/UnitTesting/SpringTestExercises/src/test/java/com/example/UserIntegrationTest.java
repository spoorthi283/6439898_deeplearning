package com.example;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class UserIntegrationTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Test
    void testCreateAndGetUser() {
        User user = new User();
        user.setId(1L);
        user.setName("Integration User");

        // POST the user
        restTemplate.postForObject("http://localhost:" + port + "/users", user, User.class);

        // GET the user back
        User result = restTemplate.getForObject("http://localhost:" + port + "/users/1", User.class);

        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo("Integration User");
    }
}
