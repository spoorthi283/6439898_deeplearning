package com.example;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.NoSuchElementException;

public class ServiceExceptionTest {

    @Mock
    UserRepository userRepository;

    @InjectMocks
    UserService userService;

    public ServiceExceptionTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testUserNotFound() {
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> userService.getUserById(99L));
    }
}