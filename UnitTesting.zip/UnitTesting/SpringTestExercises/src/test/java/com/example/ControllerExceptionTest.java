package com.example;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

@WebMvcTest(UserController.class)  // ✅ Only load UserController
public class ControllerExceptionTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;  // ✅ mock the dependency

    @Test
    public void testNotFoundException() throws Exception {
        Long userId = 100L;

        Mockito.when(userService.getUserById(userId))
               .thenThrow(new NoSuchElementException("User not found"));

        mockMvc.perform(get("/users/" + userId))
               .andExpect(status().isNotFound())
               .andExpect(content().string("User not found"));
    }
}
