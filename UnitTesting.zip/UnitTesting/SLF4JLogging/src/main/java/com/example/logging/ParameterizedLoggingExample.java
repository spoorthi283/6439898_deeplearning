package com.example.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParameterizedLoggingExample {
    private static final Logger logger = LoggerFactory.getLogger(ParameterizedLoggingExample.class);

    public static void main(String[] args) {
        String user = "Alice";
        int items = 5;
        double total = 123.45;

        logger.info("User {} purchased {} items for a total of ${}", user, items, total);
        logger.debug("Debug info: user={}, items={}, total={}", user, items, total);
    }
}
