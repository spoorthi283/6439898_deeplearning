package com.example.springrest3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@ImportResource("classpath:employee.xml")
public class Springrest3Application {

    public static void main(String[] args) {
        SpringApplication.run(Springrest3Application.class, args);
    }
}
