package com.observer;

public class Main {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();

        Observer mobileClient = new MobileApp("Alice");
        Observer webClient = new WebApp("Bob");

        stockMarket.registerObserver(mobileClient);
        stockMarket.registerObserver(webClient);

        stockMarket.setStockPrice(150.75);
        System.out.println();

        stockMarket.setStockPrice(157.20);
        System.out.println();

        stockMarket.removeObserver(webClient);
        stockMarket.setStockPrice(160.00);
    }
}
