package com.observer;

public interface Observer {
    void update(double price);
}
