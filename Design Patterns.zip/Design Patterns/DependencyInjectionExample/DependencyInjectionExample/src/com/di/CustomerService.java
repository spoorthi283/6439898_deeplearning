package com.di;

public class CustomerService {
    private CustomerRepository customerRepository;

    // Constructor injection
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public void showCustomerDetails(String customerId) {
        Customer customer = customerRepository.findCustomerById(customerId);
        if (customer != null) {
            System.out.println("Customer Found:");
            System.out.println("ID    : " + customer.getId());
            System.out.println("Name  : " + customer.getName());
            System.out.println("Email : " + customer.getEmail());
        } else {
            System.out.println("Customer not found.");
        }
    }
}
