package com.di;

public class CustomerRepositoryImpl implements CustomerRepository {

    @Override
    public Customer findCustomerById(String customerId) {
        // In a real app, you'd fetch from DB. Here, just return mock data.
        return new Customer(customerId, "Alice", "alice@example.com");
    }
}
