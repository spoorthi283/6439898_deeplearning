package com.di;

public class Main {
    public static void main(String[] args) {
        // Injecting the repository into the service
        CustomerRepository repository = new CustomerRepositoryImpl();
        CustomerService service = new CustomerService(repository);

        // Use the service to retrieve customer details
        service.showCustomerDetails("C101");
    }
}
