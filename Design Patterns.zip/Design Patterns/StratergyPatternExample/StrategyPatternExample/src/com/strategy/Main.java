package com.strategy;

public class Main {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext();

        // Use Credit Card Payment
        context.setPaymentStrategy(new CreditCardPayment("1234-5678-9999-0000", "Alice"));
        context.processPayment(250.00);

        System.out.println();

        // Use PayPal Payment
        context.setPaymentStrategy(new PayPalPayment("bob@example.com"));
        context.processPayment(99.99);
    }
}
