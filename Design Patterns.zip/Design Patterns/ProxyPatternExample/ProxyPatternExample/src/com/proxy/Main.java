package com.proxy;

public class Main {
    public static void main(String[] args) {
        Image img1 = new ProxyImage("nature.jpg");
        Image img2 = new ProxyImage("space.png");

        // First time loading
        img1.display();
        System.out.println();

        // Cached loading
        img1.display();
        System.out.println();

        // First time loading another image
        img2.display();
    }
}
