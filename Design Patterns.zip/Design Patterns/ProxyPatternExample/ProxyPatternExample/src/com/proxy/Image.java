package com.proxy;

public interface Image {
    void display();
}
