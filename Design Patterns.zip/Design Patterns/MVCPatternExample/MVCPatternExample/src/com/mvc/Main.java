package com.mvc;

public class Main {
    public static void main(String[] args) {
        // Model: Create student data
        Student student = new Student("S101", "Alice", "A");

        // View: Create view object
        StudentView view = new StudentView();

        // Controller: Bind model and view
        StudentController controller = new StudentController(student, view);

        // Display initial student details
        controller.updateView();

        System.out.println("\n--- Updating student info ---");
        controller.setStudentName("Alicia");
        controller.setStudentGrade("A+");

        // Display updated student details
        controller.updateView();
    }
}
