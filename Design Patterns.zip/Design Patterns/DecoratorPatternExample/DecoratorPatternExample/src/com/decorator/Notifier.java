package com.decorator;

public interface Notifier {
    void send(String message);
}
