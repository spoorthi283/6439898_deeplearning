package com.decorator;

public class Main {
    public static void main(String[] args) {
        Notifier emailNotifier = new EmailNotifier(); // Line 11
        Notifier smsNotifier = new SMSNotifierDecorator(emailNotifier); // Line 12
        Notifier multiChannelNotifier = new SlackNotifierDecorator(smsNotifier);// Line 13
        multiChannelNotifier.send("Your account has been accessed."); // Line 14
    }
}
