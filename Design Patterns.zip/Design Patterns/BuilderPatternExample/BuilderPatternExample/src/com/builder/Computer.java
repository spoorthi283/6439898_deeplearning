package com.builder;

public class Computer {
    // Required parameters
    private final String CPU;
    private final int RAM;

    // Optional parameters
    private final int storage;
    private final boolean hasGraphicsCard;
    private final boolean hasBluetooth;

    // Private constructor to enforce object creation through Builder
    private Computer(Builder builder) {
        this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
        this.hasGraphicsCard = builder.hasGraphicsCard;
        this.hasBluetooth = builder.hasBluetooth;
    }

    // Getters
    public String getCPU() {
        return CPU;
    }

    public int getRAM() {
        return RAM;
    }

    public int getStorage() {
        return storage;
    }

    public boolean hasGraphicsCard() {
        return hasGraphicsCard;
    }

    public boolean hasBluetooth() {
        return hasBluetooth;
    }

    @Override
    public String toString() {
        return "Computer [CPU=" + CPU + ", RAM=" + RAM + "GB, Storage=" + storage + "GB, GraphicsCard="
                + hasGraphicsCard + ", Bluetooth=" + hasBluetooth + "]";
    }

    // Static nested Builder class
    public static class Builder {
        // Required parameters
        private final String CPU;
        private final int RAM;

        // Optional parameters - initialized to default values
        private int storage = 256;
        private boolean hasGraphicsCard = false;
        private boolean hasBluetooth = false;

        // Constructor with required parameters
        public Builder(String CPU, int RAM) {
            this.CPU = CPU;
            this.RAM = RAM;
        }

        // Setter methods for optional parameters
        public Builder setStorage(int storage) {
            this.storage = storage;
            return this;
        }

        public Builder setGraphicsCard(boolean hasGraphicsCard) {
            this.hasGraphicsCard = hasGraphicsCard;
            return this;
        }

        public Builder setBluetooth(boolean hasBluetooth) {
            this.hasBluetooth = hasBluetooth;
            return this;
        }

        // Build method to return final Computer object
        public Computer build() {
            return new Computer(this);
        }
    }
}
