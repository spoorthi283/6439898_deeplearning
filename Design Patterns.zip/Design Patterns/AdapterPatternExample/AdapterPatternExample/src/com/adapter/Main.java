package com.adapter;

public class Main {
    public static void main(String[] args) {
        // Using PayPal through adapter
        PaymentProcessor payPalPayment = new PayPalAdapter(new PayPal());
        payPalPayment.processPayment(500.0);

        // Using Stripe through adapter
        PaymentProcessor stripePayment = new StripeAdapter(new Stripe());
        stripePayment.processPayment(1200.5);
    }
}
