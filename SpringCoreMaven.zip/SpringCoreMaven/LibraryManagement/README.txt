INSTRUCTIONS TO RUN PROJECT IN VS CODE:

1. Open this extracted 'LibraryManagement' folder in VS Code (File > Open Folder).
2. Make sure you see 'pom.xml' in the root.
3. Open Terminal in VS Code (Ctrl+`).
4. Run: mvn clean install
5. Then run: mvn exec:java
6. You should see output for fetching book and AOP execution time.

Do NOT open parent or sibling folders. Always open the folder that directly contains pom.xml.
