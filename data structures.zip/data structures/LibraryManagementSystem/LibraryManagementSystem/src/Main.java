public class Main {
    public static void main(String[] args) {
        Book[] books = {
                new Book(101, "The Hobbit", "J.R.R. Tolkien"),
                new Book(102, "Pride and Prejudice", "Jane Austen"),
                new Book(103, "1984", "George Orwell"),
                new Book(104, "To Kill a Mockingbird", "Harper Lee")
        };

        Library library = new Library(books);

        System.out.println("Available Books:");
        library.displayBooks();

        System.out.println("\nLinear Search: Searching for '1984'");
        Book result1 = library.linearSearchByTitle("1984");
        System.out.println(result1 != null ? result1 : "Book not found");

        System.out.println("\nBinary Search: Searching for 'To Kill a Mockingbird'");
        Book result2 = library.binarySearchByTitle("To Kill a Mockingbird");
        System.out.println(result2 != null ? result2 : "Book not found");
    }
}
