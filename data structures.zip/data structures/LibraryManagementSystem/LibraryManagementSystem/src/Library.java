import java.util.Arrays;
import java.util.Comparator;

public class Library {
    private Book[] books;

    public Library(Book[] books) {
        this.books = books;
    }

    // Linear Search
    public Book linearSearchByTitle(String title) {
        for (Book b : books) {
            if (b.getTitle().equalsIgnoreCase(title)) {
                return b;
            }
        }
        return null;
    }

    // Binary Search (list must be sorted by title)
    public Book binarySearchByTitle(String title) {
        Arrays.sort(books, Comparator.comparing(Book::getTitle));
        int low = 0, high = books.length - 1;
        while (low <= high) {
            int mid = (low + high) / 2;
            int cmp = books[mid].getTitle().compareToIgnoreCase(title);
            if (cmp == 0)
                return books[mid];
            else if (cmp < 0)
                low = mid + 1;
            else
                high = mid - 1;
        }
        return null;
    }

    // Utility to display all books
    public void displayBooks() {
        for (Book b : books) {
            System.out.println(b);
        }
    }
}
