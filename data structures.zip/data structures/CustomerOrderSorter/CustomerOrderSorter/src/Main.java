public class Main {
    public static void main(String[] args) {
        Order[] orders = {
                new Order("O1", "Alice", 1200.0),
                new Order("O2", "Bob", 450.5),
                new Order("O3", "Charlie", 1999.99),
                new Order("O4", "Diana", 700.0)
        };

        System.out.println("Original Orders:");
        for (Order o : orders)
            System.out.println(o);

        Sorter.bubbleSort(orders);
        System.out.println("\nBubble Sorted Orders:");
        for (Order o : orders)
            System.out.println(o);

        Order[] orders2 = {
                new Order("O1", "Alice", 1200.0),
                new Order("O2", "Bob", 450.5),
                new Order("O3", "Charlie", 1999.99),
                new Order("O4", "Diana", 700.0)
        };
        Sorter.quickSort(orders2, 0, orders2.length - 1);
        System.out.println("\nQuick Sorted Orders:");
        for (Order o : orders2)
            System.out.println(o);
    }
}
