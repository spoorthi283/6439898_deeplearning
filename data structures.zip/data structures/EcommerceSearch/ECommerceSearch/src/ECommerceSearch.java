import java.util.Arrays;

public class ECommerceSearch {

    public static void main(String[] args) {
        Product[] products = {
                new Product(101, "Laptop", "Electronics"),
                new Product(102, "Shampoo", "Personal Care"),
                new Product(103, "Chair", "Furniture"),
                new Product(104, "Book", "Education"),
                new Product(105, "Phone", "Electronics")
        };

        // Linear Search (no sorting needed)
        Product foundLinear = SearchFunctions.linearSearch(products, "Chair");
        System.out.println("Linear Search Result: " + foundLinear);

        // Sort products for Binary Search
        Arrays.sort(products, (a, b) -> a.productName.compareToIgnoreCase(b.productName));

        // Binary Search
        Product foundBinary = SearchFunctions.binarySearch(products, "Chair");
        System.out.println("Binary Search Result: " + foundBinary);
    }
}
