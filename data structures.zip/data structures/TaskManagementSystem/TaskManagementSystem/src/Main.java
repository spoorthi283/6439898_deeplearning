public class Main {
    public static void main(String[] args) {
        TaskManager manager = new TaskManager();

        manager.addTask(1, "Design UI", "Pending");
        manager.addTask(2, "Implement Login", "In Progress");
        manager.addTask(3, "Database Setup", "Completed");

        System.out.println("\nAll Tasks:");
        manager.listTasks();

        System.out.println("\nSearch Task ID 2:");
        Task found = manager.searchTask(2);
        System.out.println(found != null ? found : "Task not found");

        System.out.println("\nDelete Task ID 1:");
        manager.deleteTask(1);

        System.out.println("\nUpdated Task List:");
        manager.listTasks();
    }
}
