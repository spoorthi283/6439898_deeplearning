public class Main {
    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager(5); // max 5 employees

        Employee e1 = new Employee(101, "Alice", "Developer", 75000);
        Employee e2 = new Employee(102, "Bob", "Manager", 90000);
        Employee e3 = new Employee(103, "Charlie", "Analyst", 60000);

        manager.addEmployee(e1);
        manager.addEmployee(e2);
        manager.addEmployee(e3);

        System.out.println("\nAll Employees:");
        manager.listEmployees();

        System.out.println("\nSearch Employee with ID 102:");
        Employee found = manager.searchEmployee(102);
        System.out.println(found != null ? found : "Not found");

        System.out.println("\nDeleting Employee with ID 101...");
        manager.deleteEmployee(101);

        System.out.println("\nUpdated Employee List:");
        manager.listEmployees();
    }
}
